import React from 'react'
import { Redirect } from 'react-router-dom'
import {addAccount} from '../../../services/Accounts';
class Accounts extends React.Component {
    state={
        accountName:'',
        accountAdded:false,
    }
    handleAddAccount = () =>{
     addAccount(this.state.accountName)
     this.setState({
         accountAdded:true,
     })
     
    }
    handleAccountName=(e)=>
    {
        this.setState({accountName:e.target.value})
    }
    render() {
        return (
            <div>
            <input type="text" placeholder="Account Name" onChange={this.handleAccountName}></input>
            <button onClick={this.handleAddAccount}>Add Account</button>
            {this.state.accountAdded ? <Redirect to="/accounts"/> : <Redirect to="/addAccounts" />}
            </div>
        )
    }
}
export default Accounts