import React, { Component } from 'react';
import './App.css';
import {
  BrowserRouter as Router,
  Route,
  Redirect
} from 'react-router-dom';
import Login from './components/Signup';
import {localStorageGetItem , localStorageSetItem} from './services/utils';

class App extends Component {

  componentWillMount(){
    let usersStorageItem = localStorageGetItem('users');
    if(!usersStorageItem){
     localStorageSetItem('users', []);
    }
  }

  render() {
    return (
      <div className="App">
        <Router>
          <Redirect from="/" to="/login" />
          <Route exact path='/login'><Login /></Route>
        </Router>
      </div>
    );
  }
}

export default App;
