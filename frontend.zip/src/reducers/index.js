import { combineReducers } from 'redux';
import Users from './Users';

export default combineReducers({
    Users,
})